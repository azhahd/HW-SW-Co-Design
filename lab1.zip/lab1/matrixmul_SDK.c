#include <stdio.h>
#include"xmatrixmul.h"
#include"xbram.h"
#include "platform.h"
#define MAT_A_ROWS 3
#define MAT_A_COLS 3
#define MAT_B_ROWS 3
#define MAT_B_COLS 3

typedef int mat_a_t;
typedef int mat_b_t;
typedef int result_t;

void matrixmul(
      mat_a_t a[MAT_A_ROWS][MAT_A_COLS],
      mat_b_t b[MAT_B_ROWS][MAT_B_COLS],
      result_t res[MAT_A_ROWS][MAT_B_COLS]);

int main()
{
  init_platform();

 printf("Hello World\n\r");
 int i,j,k;
 mat_a_t in_mat_a[3][3] = {
              {11, 12, 13},
              {14, 15, 16},
              {17, 18 ,19}
           };
mat_a_t in_mat_b[3][3] = {
              {21, 22, 23},
              {24, 25, 26},
              {27, 28, 29}
           };

result_t hw_result[3][3], sw_result[3][3];
        int err_cnt = 0;

// Generate the expected result
// Iterate over the rows of the A matrix
 for(i = 0; i < MAT_A_ROWS; i++) {
     for(j = 0; j < MAT_B_COLS; j++) {
        // Iterate over the columns of the B matrix
         sw_result[i][j] = 0;
       // Do the inner product of a row of A and col of B
         for( k = 0; k < MAT_B_ROWS; k++) {
             sw_result[i][j] += in_mat_a[i][k] * in_mat_b[k][j];
               }
         }
       }

 //**** Hardware Initialization and Configuration ****//
XMatrixmul hwa;
XMatrixmul_Config* hwac;
XBram bram0,bram1,bram2;
XBram_Config* bramc[3];
hwac = XMatrixmul_LookupConfig(XPAR_MATRIXMUL_0_DEVICE_ID);
if(XMatrixmul_CfgInitialize(&hwa,hwac)) xil_printf("Configuration ERROR");
if(XMatrixmul_Initialize(&hwa,XPAR_MATRIXMUL_0_DEVICE_ID)) xil_printf("Initialization ERROR");

//**** BRAM Initialization and Configuration ****//
for(i=0;i<3;i++) bramc[i] = XBram_LookupConfig(i);
   if(XBram_CfgInitialize(&bram0, bramc[0],bramc[0]->CtrlBaseAddress)) return 0;// xil_printf("Error");
   //	else xil_printf("BRAM 0 Config Passed ...\n\r");
   if(XBram_CfgInitialize(&bram1, bramc[1],bramc[1]->CtrlBaseAddress)) return 0;//xil_printf("Error");
   	 	  	 			 	  	 	  //  else xil_printf("BRAM 1 Config Passed...\n\r");
   if(XBram_CfgInitialize(&bram2, bramc[2],bramc[2]->CtrlBaseAddress)) return 0;//xil_printf("Error");
   	//	else xil_printf("BRAM 2 Config Passed...\n\r");

   //**** Handshaking with matrixmul IP ****//

  if(!(XMatrixmul_IsIdle(&hwa))){
   	 	xil_printf("IP is not Idle ...\n\r");
   	 	return 0;
   	 	}
   else xil_printf("IP Ready\n\r");


   if (XMatrixmul_IsReady(&hwa))
	   xil_printf("HLS peripheral is ready.  Starting... \n\r");
   else {
   	 	xil_printf("!!! HLS peripheral is not ready! Exiting...\n\r");
   	 	return 0;
   	 	}

while(!XMatrixmul_IsReady(&hwa));

   //**** Sending and Storing data in BRAMs ****//
for (i = 0; i < MAT_A_ROWS; i++)
   for (j = 0; j < MAT_B_COLS; j++)
   	 	{
   	 	if((XPAR_AXI_BRAM_CTRL_0_S_AXI_BASEADDR+(j*sizeof(int)+i*MAT_A_ROWS*sizeof(int)))<=XPAR_AXI_BRAM_CTRL_0_S_AXI_HIGHADDR)
   	 	Xil_Out32(XPAR_AXI_BRAM_CTRL_0_S_AXI_BASEADDR+(j*sizeof(int)+i*MAT_A_ROWS*sizeof(int)),in_mat_a[i][j]);

   	 	if((XPAR_AXI_BRAM_CTRL_1_S_AXI_BASEADDR+(j*sizeof(int)+i*MAT_B_ROWS*sizeof(int)))<=XPAR_AXI_BRAM_CTRL_1_S_AXI_HIGHADDR)
   	 	Xil_Out32(XPAR_AXI_BRAM_CTRL_1_S_AXI_BASEADDR+(j*sizeof(int)+i*MAT_B_ROWS*sizeof(int)),in_mat_b[i][j]);
   	 	}
   	   XMatrixmul_Start(&hwa);
   	 	while(!XMatrixmul_IsDone(&hwa));

//**** Reading results from BRAM ****//
for (i = 0; i < MAT_A_ROWS; i++)
   	for (j = 0; j < MAT_A_COLS; j++)
   	 	 {
   	 	  if((XPAR_AXI_BRAM_CTRL_2_S_AXI_BASEADDR+(j*sizeof(int)+i*MAT_A_ROWS*sizeof(int)))<=XPAR_AXI_BRAM_CTRL_2_S_AXI_HIGHADDR)
   	 	  hw_result[i][j] = Xil_In32(XPAR_AXI_BRAM_CTRL_2_S_AXI_BASEADDR+(j*sizeof(int)+i*MAT_A_ROWS*sizeof(int)));
   	 	  }



        // Print result matrix
           xil_printf("{\r\n");
           for (i = 0; i < MAT_A_ROWS; i++) {
                   xil_printf("{");
              for (j = 0; j < MAT_B_COLS; j++) {
                      xil_printf("%d ",hw_result[i][j]);
                 // Check HW result against SW
                 if (hw_result[i][j] != sw_result[i][j]) {
                    err_cnt++;
                    xil_printf("*");
                 }
                 xil_printf("%d",sw_result[i][j]);
                 if (j == MAT_B_COLS - 1)
                         xil_printf("}\r\n");
                 else
                         xil_printf(",");
              }
           }

           xil_printf("}\r\n");
           if (err_cnt)
                   xil_printf("ERROR %d mismatches detected! \r\n",err_cnt);
           else
                   xil_printf("Test passed.\r\n");
           return err_cnt;
    }
